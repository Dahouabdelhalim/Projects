#run package installation code one time

install.packages(c("xtable", "ggplot2", "reshape2", "Hmisc", "stringr", "plyr","data.table","RColorBrewer", "gtable", "lubridate")) 
