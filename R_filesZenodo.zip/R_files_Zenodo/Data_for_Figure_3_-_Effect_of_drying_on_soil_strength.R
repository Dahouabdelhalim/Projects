#######################################################
######## Importing data

April_10_replicate_1 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/10th April 2019 replicate 1.csv")
April_10_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/10th April 2019 replicate 2.csv")
April_10_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/10th April 2019 replicate 3.csv")
April_10_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/10th April 2019 replicate 4.csv")
April_10_replicate_5 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/10th April 2019 replicate 5.csv")
April_10_replicate_6 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/10th April 2019 replicate 6.csv")

April_12_replicate_1 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/12th April 2019 replicate 1.csv")
April_12_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/12th April 2019 replicate 2.csv")
April_12_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/12th April 2019 replicate 3.csv")
April_12_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/12th April 2019 replicate 4.csv")
April_12_replicate_5 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/12th April 2019 replicate 5.csv")

April_13_replicate_1 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/13th April 2019 replicate 1.csv")
April_13_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/13th April 2019 replicate 2.csv")
April_13_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/13th April 2019 replicate 3.csv")
April_13_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/13th April 2019 replicate 4.csv")
April_13_replicate_6 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/13th April 2019 replicate 6.csv")

April_14_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/14th April 2019 replicate 2.csv")
April_14_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/14th April 2019 replicate 3.csv")
April_14_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/14th April 2019 replicate 4.csv")
April_14_replicate_5 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/14th April 2019 replicate 5.csv")
April_14_replicate_6 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/14th April 2019 replicate 6.csv")


April_15_replicate_1 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/15th April 2019 replicate 1.csv")
April_15_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/15th April 2019 replicate 2.csv")
April_15_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/15th April 2019 replicate 3.csv")
April_15_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/15th April 2019 replicate 4.csv")
April_15_replicate_5 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/15th April 2019 replicate 5.csv")
April_15_replicate_6 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/15th April 2019 replicate 6.csv")

April_16_replicate_1 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/16th April 2019 replicate 1.csv")
April_16_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/16th April 2019 replicate 2.csv")
April_16_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/16th April 2019 replicate 3.csv")
April_16_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/16th April 2019 replicate 4.csv")
April_16_replicate_5 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/16th April 2019 replicate 5.csv")
April_16_replicate_6 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/16th April 2019 replicate 6.csv")

April_17_replicate_1 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/17th April 2019 replicate 1.csv")
April_17_replicate_2 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/17th April 2019 replicate 2.csv")
April_17_replicate_3 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/17th April 2019 replicate 3.csv")
April_17_replicate_4 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/17th April 2019 replicate 4.csv")
April_17_replicate_5 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/17th April 2019 replicate 5.csv")
April_17_replicate_6 <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/17th April 2019 replicate 6.csv")


# Step1: Eliminating unnecessary columns and rows and reassigning row numbers
# Step2: Creating new columns representing size of samples and binding all data sets into a single data set
# Step 3: Declaring stress and strain as numeric and character vectors
# Step 4: Creating new columns representing size of samples and binding all data sets into a single data set


April_10_replicate_1 <- April_10_replicate_1[4:nrow(April_10_replicate_1),1:2]
row.names(April_10_replicate_1)<- 1:nrow(April_10_replicate_1)

a<- rep("10th April replicate 1",nrow(April_10_replicate_1))
a=data.frame(a)
April_10_replicate_1 = cbind(April_10_replicate_1, a)
colnames(April_10_replicate_1)=c("stress","strain","location")# naming column names
rm(a)

April_10_replicate_1$stress<- as.numeric(as.character(April_10_replicate_1$stress))
April_10_replicate_1$strain<- as.numeric(as.character(April_10_replicate_1$strain))


############

April_10_replicate_2 <- April_10_replicate_2[4:nrow(April_10_replicate_2),1:2]
row.names(April_10_replicate_2)<- 1:nrow(April_10_replicate_2)

a<- rep("10th April replicate 2",nrow(April_10_replicate_2))
a=data.frame(a)
April_10_replicate_2 = cbind(April_10_replicate_2, a)
colnames(April_10_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_10_replicate_2$stress<- as.numeric(as.character(April_10_replicate_2$stress))
April_10_replicate_2$strain<- as.numeric(as.character(April_10_replicate_2$strain))

############

April_10_replicate_3 <- April_10_replicate_3[4:nrow(April_10_replicate_3),1:2]
row.names(April_10_replicate_3)<- 1:nrow(April_10_replicate_3)

a<- rep("10th April replicate 3",nrow(April_10_replicate_3))
a=data.frame(a)
April_10_replicate_3 = cbind(April_10_replicate_3, a)
colnames(April_10_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_10_replicate_3$stress<- as.numeric(as.character(April_10_replicate_3$stress))
April_10_replicate_3$strain<- as.numeric(as.character(April_10_replicate_3$strain))

############

April_10_replicate_4 <- April_10_replicate_4[4:nrow(April_10_replicate_4),1:2]
row.names(April_10_replicate_4)<- 1:nrow(April_10_replicate_4)

a<- rep("10th April replicate 4",nrow(April_10_replicate_4))
a=data.frame(a)
April_10_replicate_4 = cbind(April_10_replicate_4, a)
colnames(April_10_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_10_replicate_4$stress<- as.numeric(as.character(April_10_replicate_4$stress))
April_10_replicate_4$strain<- as.numeric(as.character(April_10_replicate_4$strain))

############

April_10_replicate_5 <- April_10_replicate_5[4:nrow(April_10_replicate_5),1:2]
row.names(April_10_replicate_5)<- 1:nrow(April_10_replicate_5)

a<- rep("10th April replicate 5",nrow(April_10_replicate_5))
a=data.frame(a)
April_10_replicate_5 = cbind(April_10_replicate_5, a)
colnames(April_10_replicate_5)=c("stress","strain","location")# naming column names
rm(a)

April_10_replicate_5$stress<- as.numeric(as.character(April_10_replicate_5$stress))
April_10_replicate_5$strain<- as.numeric(as.character(April_10_replicate_5$strain))

############

April_10_replicate_6 <- April_10_replicate_6[4:nrow(April_10_replicate_6),1:2]
row.names(April_10_replicate_6)<- 1:nrow(April_10_replicate_6)

a<- rep("10th April replicate 6",nrow(April_10_replicate_6))
a=data.frame(a)
April_10_replicate_6 = cbind(April_10_replicate_6, a)
colnames(April_10_replicate_6)=c("stress","strain","location")# naming column names
rm(a)

April_10_replicate_6$stress<- as.numeric(as.character(April_10_replicate_6$stress))
April_10_replicate_6$strain<- as.numeric(as.character(April_10_replicate_6$strain))


############


April_12_replicate_1 <- April_12_replicate_1[4:nrow(April_12_replicate_1),1:2]
row.names(April_12_replicate_1)<- 1:nrow(April_12_replicate_1)

a<- rep("12th April replicate 1",nrow(April_12_replicate_1))
a=data.frame(a)
April_12_replicate_1 = cbind(April_12_replicate_1, a)
colnames(April_12_replicate_1)=c("stress","strain","location")# naming column names
rm(a)

April_12_replicate_1$stress<- as.numeric(as.character(April_12_replicate_1$stress))
April_12_replicate_1$strain<- as.numeric(as.character(April_12_replicate_1$strain))


############

April_12_replicate_2 <- April_12_replicate_2[4:nrow(April_12_replicate_2),1:2]
row.names(April_12_replicate_2)<- 1:nrow(April_12_replicate_2)

a<- rep("12th April replicate 2",nrow(April_12_replicate_2))
a=data.frame(a)
April_12_replicate_2 = cbind(April_12_replicate_2, a)
colnames(April_12_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_12_replicate_2$stress<- as.numeric(as.character(April_12_replicate_2$stress))
April_12_replicate_2$strain<- as.numeric(as.character(April_12_replicate_2$strain))

############

April_12_replicate_3 <- April_12_replicate_3[4:nrow(April_12_replicate_3),1:2]
row.names(April_12_replicate_3)<- 1:nrow(April_12_replicate_3)

a<- rep("12th April replicate 3",nrow(April_12_replicate_3))
a=data.frame(a)
April_12_replicate_3 = cbind(April_12_replicate_3, a)
colnames(April_12_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_12_replicate_3$stress<- as.numeric(as.character(April_12_replicate_3$stress))
April_12_replicate_3$strain<- as.numeric(as.character(April_12_replicate_3$strain))

############

April_12_replicate_4 <- April_12_replicate_4[4:nrow(April_12_replicate_4),1:2]
row.names(April_12_replicate_4)<- 1:nrow(April_12_replicate_4)

a<- rep("12th April replicate 4",nrow(April_12_replicate_4))
a=data.frame(a)
April_12_replicate_4 = cbind(April_12_replicate_4, a)
colnames(April_12_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_12_replicate_4$stress<- as.numeric(as.character(April_12_replicate_4$stress))
April_12_replicate_4$strain<- as.numeric(as.character(April_12_replicate_4$strain))

############

April_12_replicate_5 <- April_12_replicate_5[4:nrow(April_12_replicate_5),1:2]
row.names(April_12_replicate_5)<- 1:nrow(April_12_replicate_5)

a<- rep("12th April replicate 5",nrow(April_12_replicate_5))
a=data.frame(a)
April_12_replicate_5 = cbind(April_12_replicate_5, a)
colnames(April_12_replicate_5)=c("stress","strain","location")# naming column names
rm(a)

April_12_replicate_5$stress<- as.numeric(as.character(April_12_replicate_5$stress))
April_12_replicate_5$strain<- as.numeric(as.character(April_12_replicate_5$strain))

############

April_13_replicate_1 <- April_13_replicate_1[4:nrow(April_13_replicate_1),1:2]
row.names(April_13_replicate_1)<- 1:nrow(April_13_replicate_1)

a<- rep("13th April replicate 1",nrow(April_13_replicate_1))
a=data.frame(a)
April_13_replicate_1 = cbind(April_13_replicate_1, a)
colnames(April_13_replicate_1)=c("stress","strain","location")# naming column names
rm(a)

April_13_replicate_1$stress<- as.numeric(as.character(April_13_replicate_1$stress))
April_13_replicate_1$strain<- as.numeric(as.character(April_13_replicate_1$strain))


############

April_13_replicate_2 <- April_13_replicate_2[4:nrow(April_13_replicate_2),1:2]
row.names(April_13_replicate_2)<- 1:nrow(April_13_replicate_2)

a<- rep("13th April replicate 2",nrow(April_13_replicate_2))
a=data.frame(a)
April_13_replicate_2 = cbind(April_13_replicate_2, a)
colnames(April_13_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_13_replicate_2$stress<- as.numeric(as.character(April_13_replicate_2$stress))
April_13_replicate_2$strain<- as.numeric(as.character(April_13_replicate_2$strain))

############

April_13_replicate_3 <- April_13_replicate_3[4:nrow(April_13_replicate_3),1:2]
row.names(April_13_replicate_3)<- 1:nrow(April_13_replicate_3)

a<- rep("13th April replicate 3",nrow(April_13_replicate_3))
a=data.frame(a)
April_13_replicate_3 = cbind(April_13_replicate_3, a)
colnames(April_13_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_13_replicate_3$stress<- as.numeric(as.character(April_13_replicate_3$stress))
April_13_replicate_3$strain<- as.numeric(as.character(April_13_replicate_3$strain))

############

April_13_replicate_4 <- April_13_replicate_4[4:nrow(April_13_replicate_4),1:2]
row.names(April_13_replicate_4)<- 1:nrow(April_13_replicate_4)

a<- rep("13th April replicate 4",nrow(April_13_replicate_4))
a=data.frame(a)
April_13_replicate_4 = cbind(April_13_replicate_4, a)
colnames(April_13_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_13_replicate_4$stress<- as.numeric(as.character(April_13_replicate_4$stress))
April_13_replicate_4$strain<- as.numeric(as.character(April_13_replicate_4$strain))

############

April_13_replicate_6 <- April_13_replicate_6[4:nrow(April_13_replicate_6),1:2]
row.names(April_13_replicate_6)<- 1:nrow(April_13_replicate_6)

a<- rep("13th April replicate 6",nrow(April_13_replicate_6))
a=data.frame(a)
April_13_replicate_6 = cbind(April_13_replicate_6, a)
colnames(April_13_replicate_6)=c("stress","strain","location")# naming column names
rm(a)

April_13_replicate_6$stress<- as.numeric(as.character(April_13_replicate_6$stress))
April_13_replicate_6$strain<- as.numeric(as.character(April_13_replicate_6$strain))

############

April_14_replicate_2 <- April_14_replicate_2[4:nrow(April_14_replicate_2),1:2]
row.names(April_14_replicate_2)<- 1:nrow(April_14_replicate_2)

a<- rep("14th April replicate 2",nrow(April_14_replicate_2))
a=data.frame(a)
April_14_replicate_2 = cbind(April_14_replicate_2, a)
colnames(April_14_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_14_replicate_2$stress<- as.numeric(as.character(April_14_replicate_2$stress))
April_14_replicate_2$strain<- as.numeric(as.character(April_14_replicate_2$strain))


############

April_14_replicate_3 <- April_14_replicate_3[4:nrow(April_14_replicate_3),1:2]
row.names(April_14_replicate_3)<- 1:nrow(April_14_replicate_3)

a<- rep("14th April replicate 3",nrow(April_14_replicate_3))
a=data.frame(a)
April_14_replicate_3 = cbind(April_14_replicate_3, a)
colnames(April_14_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_14_replicate_3$stress<- as.numeric(as.character(April_14_replicate_3$stress))
April_14_replicate_3$strain<- as.numeric(as.character(April_14_replicate_3$strain))

############

April_14_replicate_4 <- April_14_replicate_4[4:nrow(April_14_replicate_4),1:2]
row.names(April_14_replicate_4)<- 1:nrow(April_14_replicate_4)

a<- rep("14th April replicate 4",nrow(April_14_replicate_4))
a=data.frame(a)
April_14_replicate_4 = cbind(April_14_replicate_4, a)
colnames(April_14_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_14_replicate_4$stress<- as.numeric(as.character(April_14_replicate_4$stress))
April_14_replicate_4$strain<- as.numeric(as.character(April_14_replicate_4$strain))

############

April_14_replicate_5 <- April_14_replicate_5[4:nrow(April_14_replicate_5),1:2]
row.names(April_14_replicate_5)<- 1:nrow(April_14_replicate_5)

a<- rep("14th April replicate 5",nrow(April_14_replicate_5))
a=data.frame(a)
April_14_replicate_5 = cbind(April_14_replicate_5, a)
colnames(April_14_replicate_5)=c("stress","strain","location")# naming column names
rm(a)

April_14_replicate_5$stress<- as.numeric(as.character(April_14_replicate_5$stress))
April_14_replicate_5$strain<- as.numeric(as.character(April_14_replicate_5$strain))

############

April_14_replicate_6 <- April_14_replicate_6[4:nrow(April_14_replicate_6),1:2]
row.names(April_14_replicate_6)<- 1:nrow(April_14_replicate_6)

a<- rep("14th April replicate 6",nrow(April_14_replicate_6))
a=data.frame(a)
April_14_replicate_6 = cbind(April_14_replicate_6, a)
colnames(April_14_replicate_6)=c("stress","strain","location")# naming column names
rm(a)

April_14_replicate_6$stress<- as.numeric(as.character(April_14_replicate_6$stress))
April_14_replicate_6$strain<- as.numeric(as.character(April_14_replicate_6$strain))

############

April_15_replicate_2 <- April_15_replicate_2[4:nrow(April_15_replicate_2),1:2]
row.names(April_15_replicate_2)<- 1:nrow(April_15_replicate_2)

a<- rep("15th April replicate 1",nrow(April_15_replicate_2))
a=data.frame(a)
April_15_replicate_2 = cbind(April_15_replicate_2, a)
colnames(April_15_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_15_replicate_2$stress<- as.numeric(as.character(April_15_replicate_2$stress))
April_15_replicate_2$strain<- as.numeric(as.character(April_15_replicate_2$strain))

############

April_15_replicate_3 <- April_15_replicate_3[4:nrow(April_15_replicate_3),1:2]
row.names(April_15_replicate_3)<- 1:nrow(April_15_replicate_3)

a<- rep("15th April replicate 3",nrow(April_15_replicate_3))
a=data.frame(a)
April_15_replicate_3 = cbind(April_15_replicate_3, a)
colnames(April_15_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_15_replicate_3$stress<- as.numeric(as.character(April_15_replicate_3$stress))
April_15_replicate_3$strain<- as.numeric(as.character(April_15_replicate_3$strain))

############

April_15_replicate_4 <- April_15_replicate_4[4:nrow(April_15_replicate_4),1:2]
row.names(April_15_replicate_4)<- 1:nrow(April_15_replicate_4)

a<- rep("15th April replicate 4",nrow(April_15_replicate_4))
a=data.frame(a)
April_15_replicate_4 = cbind(April_15_replicate_4, a)
colnames(April_15_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_15_replicate_4$stress<- as.numeric(as.character(April_15_replicate_4$stress))
April_15_replicate_4$strain<- as.numeric(as.character(April_15_replicate_4$strain))

############

April_15_replicate_5 <- April_15_replicate_5[4:nrow(April_15_replicate_5),1:2]
row.names(April_15_replicate_5)<- 1:nrow(April_15_replicate_5)

a<- rep("15th April replicate 5",nrow(April_15_replicate_5))
a=data.frame(a)
April_15_replicate_5 = cbind(April_15_replicate_5, a)
colnames(April_15_replicate_5)=c("stress","strain","location")# naming column names
rm(a)

April_15_replicate_5$stress<- as.numeric(as.character(April_15_replicate_5$stress))
April_15_replicate_5$strain<- as.numeric(as.character(April_15_replicate_5$strain))

############

April_15_replicate_6 <- April_15_replicate_6[4:nrow(April_15_replicate_6),1:2]
row.names(April_15_replicate_6)<- 1:nrow(April_15_replicate_6)

a<- rep("15th April replicate 6",nrow(April_15_replicate_6))
a=data.frame(a)
April_15_replicate_6 = cbind(April_15_replicate_6, a)
colnames(April_15_replicate_6)=c("stress","strain","location")# naming column names
rm(a)

April_15_replicate_6$stress<- as.numeric(as.character(April_15_replicate_6$stress))
April_15_replicate_6$strain<- as.numeric(as.character(April_15_replicate_6$strain))

############

April_16_replicate_1 <- April_16_replicate_1[4:nrow(April_16_replicate_1),1:2]
row.names(April_16_replicate_1)<- 1:nrow(April_16_replicate_1)

a<- rep("16th April replicate 1",nrow(April_16_replicate_1))
a=data.frame(a)
April_16_replicate_1 = cbind(April_16_replicate_1, a)
colnames(April_16_replicate_1)=c("stress","strain","location")# naming column names
rm(a)

April_16_replicate_1$stress<- as.numeric(as.character(April_16_replicate_1$stress))
April_16_replicate_1$strain<- as.numeric(as.character(April_16_replicate_1$strain))

############

April_16_replicate_2 <- April_16_replicate_2[4:nrow(April_16_replicate_2),1:2]
row.names(April_16_replicate_2)<- 1:nrow(April_16_replicate_2)

a<- rep("16th April replicate 2",nrow(April_16_replicate_2))
a=data.frame(a)
April_16_replicate_2 = cbind(April_16_replicate_2, a)
colnames(April_16_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_16_replicate_2$stress<- as.numeric(as.character(April_16_replicate_2$stress))
April_16_replicate_2$strain<- as.numeric(as.character(April_16_replicate_2$strain))

############

April_16_replicate_3 <- April_16_replicate_3[4:nrow(April_16_replicate_3),1:2]
row.names(April_16_replicate_3)<- 1:nrow(April_16_replicate_3)

a<- rep("16th April replicate 3",nrow(April_16_replicate_3))
a=data.frame(a)
April_16_replicate_3 = cbind(April_16_replicate_3, a)
colnames(April_16_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_16_replicate_3$stress<- as.numeric(as.character(April_16_replicate_3$stress))
April_16_replicate_3$strain<- as.numeric(as.character(April_16_replicate_3$strain))

############

April_16_replicate_4 <- April_16_replicate_4[4:nrow(April_16_replicate_4),1:2]
row.names(April_16_replicate_4)<- 1:nrow(April_16_replicate_4)

a<- rep("16th April replicate 4",nrow(April_16_replicate_4))
a=data.frame(a)
April_16_replicate_4 = cbind(April_16_replicate_4, a)
colnames(April_16_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_16_replicate_4$stress<- as.numeric(as.character(April_16_replicate_4$stress))
April_16_replicate_4$strain<- as.numeric(as.character(April_16_replicate_4$strain))

############

April_16_replicate_5 <- April_16_replicate_5[4:nrow(April_16_replicate_5),1:2]
row.names(April_16_replicate_5)<- 1:nrow(April_16_replicate_5)

a<- rep("16th April replicate 5",nrow(April_16_replicate_5))
a=data.frame(a)
April_16_replicate_5 = cbind(April_16_replicate_5, a)
colnames(April_16_replicate_5)=c("stress","strain","location")# naming column names
rm(a)

April_16_replicate_5$stress<- as.numeric(as.character(April_16_replicate_5$stress))
April_16_replicate_5$strain<- as.numeric(as.character(April_16_replicate_5$strain))

############

April_16_replicate_6 <- April_16_replicate_6[4:nrow(April_16_replicate_6),1:2]
row.names(April_16_replicate_6)<- 1:nrow(April_16_replicate_6)

a<- rep("16th April replicate 6",nrow(April_16_replicate_6))
a=data.frame(a)
April_16_replicate_6 = cbind(April_16_replicate_6, a)
colnames(April_16_replicate_6)=c("stress","strain","location")# naming column names
rm(a)

April_16_replicate_6$stress<- as.numeric(as.character(April_16_replicate_6$stress))
April_16_replicate_6$strain<- as.numeric(as.character(April_16_replicate_6$strain))

############

April_17_replicate_1 <- April_17_replicate_1[4:nrow(April_17_replicate_1),1:2]
row.names(April_17_replicate_1)<- 1:nrow(April_17_replicate_1)

a<- rep("17th April replicate 1",nrow(April_17_replicate_1))
a=data.frame(a)
April_17_replicate_1 = cbind(April_17_replicate_1, a)
colnames(April_17_replicate_1)=c("stress","strain","location")# naming column names
rm(a)

April_17_replicate_1$stress<- as.numeric(as.character(April_17_replicate_1$stress))
April_17_replicate_1$strain<- as.numeric(as.character(April_17_replicate_1$strain))

############

April_17_replicate_2 <- April_17_replicate_2[4:nrow(April_17_replicate_2),1:2]
row.names(April_17_replicate_2)<- 1:nrow(April_17_replicate_2)

a<- rep("17th April replicate 2",nrow(April_17_replicate_2))
a=data.frame(a)
April_17_replicate_2 = cbind(April_17_replicate_2, a)
colnames(April_17_replicate_2)=c("stress","strain","location")# naming column names
rm(a)

April_17_replicate_2$stress<- as.numeric(as.character(April_17_replicate_2$stress))
April_17_replicate_2$strain<- as.numeric(as.character(April_17_replicate_2$strain))

############

April_17_replicate_3 <- April_17_replicate_3[4:nrow(April_17_replicate_3),1:2]
row.names(April_17_replicate_3)<- 1:nrow(April_17_replicate_3)

a<- rep("17th April replicate 3",nrow(April_17_replicate_3))
a=data.frame(a)
April_17_replicate_3 = cbind(April_17_replicate_3, a)
colnames(April_17_replicate_3)=c("stress","strain","location")# naming column names
rm(a)

April_17_replicate_3$stress<- as.numeric(as.character(April_17_replicate_3$stress))
April_17_replicate_3$strain<- as.numeric(as.character(April_17_replicate_3$strain))

############

April_17_replicate_4 <- April_17_replicate_4[4:nrow(April_17_replicate_4),1:2]
row.names(April_17_replicate_4)<- 1:nrow(April_17_replicate_4)

a<- rep("17th April replicate 4",nrow(April_17_replicate_4))
a=data.frame(a)
April_17_replicate_4 = cbind(April_17_replicate_4, a)
colnames(April_17_replicate_4)=c("stress","strain","location")# naming column names
rm(a)

April_17_replicate_4$stress<- as.numeric(as.character(April_17_replicate_4$stress))
April_17_replicate_4$strain<- as.numeric(as.character(April_17_replicate_4$strain))

############

April_17_replicate_5 <- April_17_replicate_5[4:nrow(April_17_replicate_5),1:2]
row.names(April_17_replicate_5)<- 1:nrow(April_17_replicate_5)

a<- rep("17th April replicate 5",nrow(April_17_replicate_5))
a=data.frame(a)
April_17_replicate_5 = cbind(April_17_replicate_5, a)
colnames(April_17_replicate_5)=c("stress","strain","location")# naming column names
rm(a)

April_17_replicate_5$stress<- as.numeric(as.character(April_17_replicate_5$stress))
April_17_replicate_5$strain<- as.numeric(as.character(April_17_replicate_5$strain))

############

April_17_replicate_6 <- April_17_replicate_6[4:nrow(April_17_replicate_6),1:2]
row.names(April_17_replicate_6)<- 1:nrow(April_17_replicate_6)

a<- rep("17th April replicate 6",nrow(April_17_replicate_6))
a=data.frame(a)
April_17_replicate_6 = cbind(April_17_replicate_6, a)
colnames(April_17_replicate_6)=c("stress","strain","location")# naming column names
rm(a)

April_17_replicate_6$stress<- as.numeric(as.character(April_17_replicate_6$stress))
April_17_replicate_6$strain<- as.numeric(as.character(April_17_replicate_6$strain))




######################################################################
## Plotting samples individually


plot(April_10_replicate_1$strain, April_10_replicate_1$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 10th replicate 1")

############

plot(April_10_replicate_2$strain, April_10_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 10th replicate 2")

############

plot(April_10_replicate_3$strain, April_10_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 10th replicate 3")

############

plot(April_10_replicate_4$strain, April_10_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 10th replicate 4")

############

plot(April_10_replicate_5$strain, April_10_replicate_5$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 10th replicate 5")

############

plot(April_10_replicate_6$strain, April_10_replicate_6$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 10th replicate 6")

############

plot(April_12_replicate_1$strain, April_12_replicate_1$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 12th replicate 1")

############

plot(April_12_replicate_2$strain, April_12_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 12th replicate 2")

############

plot(April_12_replicate_3$strain, April_12_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 12th replicate 3")

############

plot(April_12_replicate_4$strain, April_12_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 12th replicate 4")

############

plot(April_12_replicate_5$strain, April_12_replicate_5$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 12th replicate 5")

############

plot(April_13_replicate_1$strain, April_13_replicate_1$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 13th replicate 1")


############

plot(April_13_replicate_2$strain, April_13_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 13th replicate 2")

############

plot(April_13_replicate_3$strain, April_13_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 13th replicate 3")

############

plot(April_13_replicate_4$strain, April_13_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 13th replicate 4")

############

plot(April_13_replicate_6$strain, April_13_replicate_6$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 13th replicate 6")


############

plot(April_14_replicate_2$strain, April_14_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 14th replicate 2")

############

plot(April_14_replicate_3$strain, April_14_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 14th replicate 3")

############

plot(April_14_replicate_4$strain, April_14_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 14th replicate 4")

############

plot(April_14_replicate_5$strain, April_14_replicate_5$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 14th replicate 5")

############

plot(April_14_replicate_6$strain, April_14_replicate_6$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 14th replicate 6")

############

plot(April_15_replicate_2$strain, April_15_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 15th replicate 2")

############

plot(April_15_replicate_3$strain, April_15_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 15th replicate 3")

############

plot(April_15_replicate_4$strain, April_15_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 15th replicate 4")

############

plot(April_15_replicate_5$strain, April_15_replicate_5$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 15th replicate 5")

############

plot(April_15_replicate_6$strain, April_15_replicate_6$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 15th replicate 6")

############

plot(April_16_replicate_1$strain, April_16_replicate_1$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 16th replicate 1")

############

plot(April_16_replicate_2$strain, April_16_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 16th replicate 2")

############

plot(April_16_replicate_3$strain, April_16_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 16th replicate 3")

############

plot(April_16_replicate_4$strain, April_16_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 16th replicate 4")

############

plot(April_16_replicate_5$strain, April_16_replicate_5$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 16th replicate 5")

############

plot(April_16_replicate_6$strain, April_16_replicate_6$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 16th replicate 6")

############

plot(April_17_replicate_1$strain, April_17_replicate_1$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 17th replicate 1")

############

plot(April_17_replicate_2$strain, April_17_replicate_2$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 17th replicate 2")

############

plot(April_17_replicate_3$strain, April_17_replicate_3$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 17th replicate 3")

############

plot(April_17_replicate_4$strain, April_17_replicate_4$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 17th replicate 4")

############

plot(April_17_replicate_5$strain, April_17_replicate_5$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 17th replicate 5")

############

plot(April_17_replicate_6$strain, April_17_replicate_6$stress,
     type="l", col="blue",
     xlab="Strain (%)", ylab="Stress (kPa)",
     main="April 17th replicate 6")


##################################################
### peak stress values plotting

max(April_10_replicate_1$stress)
max(April_10_replicate_2$stress)
max(April_10_replicate_3$stress)
max(April_10_replicate_4$stress)
max(April_10_replicate_5$stress)
max(April_10_replicate_6$stress)

max(April_12_replicate_1$stress)
max(April_12_replicate_2$stress)
max(April_12_replicate_3$stress)
max(April_12_replicate_4$stress)
max(April_12_replicate_5$stress)

max(April_13_replicate_1$stress)
max(April_13_replicate_2$stress)
max(April_13_replicate_3$stress)
max(April_13_replicate_4$stress)
max(April_13_replicate_6$stress)

max(April_14_replicate_2$stress)
max(April_14_replicate_3$stress)
max(April_14_replicate_4$stress)
max(April_14_replicate_5$stress)
max(April_14_replicate_6$stress)

max(April_15_replicate_2$stress)
max(April_15_replicate_3$stress)
max(April_15_replicate_4$stress)
max(April_15_replicate_5$stress)
max(April_15_replicate_6$stress)

max(April_16_replicate_1$stress)
max(April_16_replicate_2$stress)
max(April_16_replicate_3$stress)
max(April_16_replicate_4$stress)
max(April_16_replicate_5$stress)
max(April_16_replicate_6$stress)

max(April_17_replicate_1$stress)
max(April_17_replicate_2$stress)
max(April_17_replicate_3$stress)
max(April_17_replicate_4$stress)
max(April_17_replicate_5$stress)
max(April_17_replicate_6$stress)


## Statistics 

data <- read.csv("~/Desktop/Strength and weathering resistance of termite mounds/Data for Figure 3 - Effect of drying on soil strength/Effect of drying on soil strength - statistics.csv")
Days <- factor(data$Days)
levels(Days)

mod1 <- lm(data$Stress ~ Days)
summary(mod1)
plot(residuals(mod1))
shapiro.test(residuals(mod1))

mod1 <- aov(data$Stress ~ Days)
summary(mod1)

TukeyHSD(x=mod1, conf.level=0.95)
